#!/bin/bash
sudo apt-get install nethogs && sudo nethogs "$@"
